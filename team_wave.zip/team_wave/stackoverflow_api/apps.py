from django.apps import AppConfig


class StackoverflowApiConfig(AppConfig):
    name = 'stackoverflow_api'
