from django.contrib import admin

from .models import Cache

admin.site.register(Cache)

