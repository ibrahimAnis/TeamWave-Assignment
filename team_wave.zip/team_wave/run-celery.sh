celery -A team_wave worker -l info
